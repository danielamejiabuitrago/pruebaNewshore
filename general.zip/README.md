## 😋 Iniciar el proceso de sass

 npm run do

## 😋 Iniciar proyecto

 node index.js

## 1. 😋 Dominio temporal donde se puede visualizar

## - Autor

 Daniela Mejía

## - Codigo fuente

 Carpeta src
